
public class Tester {

	public static void main(String[] args) {
		int num1, num2, sum;
		double average;
		
		num1 = 16;
		num2 = 12;
		sum = num1 + num2;
		average = sum / 2.0;
		
		System.out.println("The sum of " + num1 + " and " + num2 + " is " + sum);
		System.out.println("The average is " + average + ".");

	}

}
