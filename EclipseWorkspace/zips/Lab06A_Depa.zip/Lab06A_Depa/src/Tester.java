/**
 * Lab06A - Foxes v1
 * @author Barnes, Kolling 
 * adapted by Prof W for OOPDA
 *
 */
public class Tester {

	public static void main(String[] args) {
			Simulator sim = new Simulator();
			//sim.runLongSimulation();
			sim.simulate(500);

	}

}
